package com.example.aoaconnect;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.hardware.usb.UsbAccessory;
import android.hardware.usb.UsbManager;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.util.Log;
import android.widget.TextView;

import java.io.FileDescriptor;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

/*
Inception - Android Environment:
Application opened by usb attachment, automatic detection via intent filter in manifest
As such, explicit request of user permission is unnecessary; opening of app implies compliance

Open Communication Channels - openAccessory();
Declare UsbManager (accessory enum/comm) and UsbAccessory(accessory info)
Set up FileDescriptor (memory address for .txt) and file i/o streams
Handoff to worker thread for data exchange
 */

public class MainActivity extends AppCompatActivity implements Runnable{
    UsbManager usbManager = (UsbManager)getSystemService(Context.USB_SERVICE);
    UsbAccessory accessory;
    ParcelFileDescriptor fileDescriptor;
    FileInputStream inputStream;
    FileOutputStream outputStream;

    private void openAccessory(){
        Log.d("Ignite ", "openAccessory: " + accessory);
        fileDescriptor = usbManager.openAccessory(accessory);
        if(fileDescriptor != null){
            FileDescriptor fd = fileDescriptor.getFileDescriptor();
            inputStream = new FileInputStream(fd);
            outputStream = new FileOutputStream(fd);
            Thread thread = new Thread(null, this, "AccessoryThread");
            thread.start();
        }
    }

    @Override
    public void run(){
       try {
           outputStream.write(accessory.hashCode());
           TextView t = findViewById(R.id.data);
           t.setText(inputStream.read());
           outputStream.close();
           inputStream.close();
       }
       catch(IOException e) {
           e.printStackTrace();
       }
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.openAccessory();
    }
}
